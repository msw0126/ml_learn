This folder contains git subtree projects of xgboost.
Do not make changes to the subtree projects in xgboost,
push changes to the original project instead and changes will be pulled back to this folder

* rabit: https://github.com/tqchen/rabit
